"use client"

import OtplessComponent from "@/components/auth/signIn"

export default function Registerpage() {
    return(

        <div className="w-full h-full flex p-5 md:p-0 flex-col items-center justify-center min-h-screen">
           <OtplessComponent/>
        </div>

    )
}